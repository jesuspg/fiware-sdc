maintainer       "Telefonica I+D"
maintainer_email "jesus.movilla@altran.es"
license          "All rights reserved"
description      "Installs/Configures different tomcat versions"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.1.0"
