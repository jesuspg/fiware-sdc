node.default[:postgresql][:version] = "8.4"
include_recipe "postgresql::server_uninstall"
