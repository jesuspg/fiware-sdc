#
# Cookbook Name:: tomcat
# Recipe:: default
#
# Copyright 2011, Telefonica I+D
#
# Author: Jesus M. Movilla
#
# All rights reserved - Do Not Redistribute
#

include_recipe "tomcat::7_install"
